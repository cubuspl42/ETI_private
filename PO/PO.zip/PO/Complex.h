//
//  Complex.h
//  PO
//
//  Created by Jakub Trzebiatowski on 04/03/15.
//  Copyright (c) 2015 Jakub Trzebiatowski. All rights reserved.
//

#ifndef PO_Complex_h
#define PO_Complex_h

#include "Liczba.h"
#include <iostream>

class Complex : public Wartosc_Liczbowa {
protected: double re; double im; //czesc urojona
public: ~Complex(void);
    Complex(double re=0,double im=0);
    Complex operator +(Complex &);
    friend std::ostream & operator<< (std::ostream &out, Complex &l);
    double modul();
    void wypisz(std::ostream &out) { out<<*this; }
};

#endif
