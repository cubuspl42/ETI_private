//
//  main.cpp
//  PO
//
//  Created by Jakub Trzebiatowski on 04/03/15.
//  Copyright (c) 2015 Jakub Trzebiatowski. All rights reserved.
//

#include <iostream>

using namespace std;



int main(int argc, const char * argv[]) {
    
}
